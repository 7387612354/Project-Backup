({
    negupdateColumnSorting: function (cmp, event, helper)
    {
        let fieldName = event.getParam('fieldName');
        let sortDirection = event.getParam('sortDirection');
        cmp.set("v.negsortedBy", fieldName);
        cmp.set("v.negsortedDirection", sortDirection);
        helper.negsortData(cmp, fieldName, sortDirection);
    },
    neghandleRowAction: function (cmp, event, helper)
    {
        let row = event.getParam('row');
        cmp.set('v.selectesRec', row);
        cmp.set("v.openModal", true);
    },
    
    doInit: function (cmp, event, helper)
    {
        let staticLabel1 = $A.get("$Label.c.CA_Negative_Header");
        let staticLabel2 = $A.get("$Label.c.CA_ScheduleButton");
        let staticLabel3 = $A.get("$Label.c.CA_ActionHeader");
        let staticLabel4 = $A.get("$Label.c.CA_Priority_Do_Not_Visit_Flag_Neg_Header");
        let staticLabel5 = $A.get("$Label.c.CA_Account_Name_Header_Label");
        let staticLabel6 = $A.get("$Label.c.CA_Last_Call_Date_Header_Label");
        let staticLabel7 = $A.get("$Label.c.CA_Completed_Call_of_this_Month_Header_Label");
        let staticLabel8 = $A.get("$Label.c.CA_Call_Frequency_Header_Label");
        let staticLabel9 = $A.get("$Label.c.CA_Predicted_Sales_Monthly_Header_Label");
        let staticLabel10 = $A.get("$Label.c.CA_Sales_Monthly_Header_Label");
        let staticLabel11 = $A.get("$Label.c.CA_Segment_Header_Label");
        let staticLabel12 = $A.get("$Label.c.CA_Procedures_Header_Label");
        let staticLabel13 = $A.get("$Label.c.CA_JnJ_Share_Header_Label");
        let staticLabel14 = $A.get("$Label.c.CA_Dr1_Header_Label");
		let staticLabel15 = $A.get("$Label.c.CA_Available_Datetime1_Header_Label");
		let staticLabel16 = $A.get("$Label.c.CA_Dr2_Header_Label");
		let staticLabel17 = $A.get("$Label.c.CA_Available_Datetime2_Header_Label");
		let staticLabel18 = $A.get("$Label.c.CA_Address_Header_Label");
        
        cmp.set("v.CA_Negative_Header", staticLabel1);
        cmp.set('v.accName', 'selectesRec.AccountId__c');
        cmp.set('v.negmycolumns', [
            {
                label: staticLabel3,
                type: 'button',
                typeAttributes:
                {
                    iconName: 'utility:view',
                    label: staticLabel2,
                    name: 'viewNegRecord',
                    disabled: false,
                    value: 'viewBtn',
                    variant: { fieldName: 'negbuttonColor' }
                },
                "initialWidth": 155
            },
            {
                label: staticLabel4,
                fieldName: 'Concate_Priority_and_Do_not_Visit_Flag__c',
                type: 'text',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: staticLabel5,
                fieldName: 'linkName',
                type: 'url',
                typeAttributes: {
                    label: { fieldName: 'Account_Name__c' },
                    target: '_blank'
                },
                "initialWidth": 155
            },
            {
                label: staticLabel6,
                fieldName: 'Last_Call_Date_Formula__c',
                type: 'text',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: staticLabel7,
                fieldName: 'concate_Completed_Call_and_Incoming_Call__c',
                type: 'text',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: staticLabel8,
                fieldName: 'Call_Frequency_Monthly__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: staticLabel9,
                fieldName: 'Predicted_IOL_Sales_Amount__c',
                type: 'currency',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: staticLabel10,
                fieldName: 'IOL_sales__c',
                type: 'currency',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: staticLabel11,
                fieldName: 'Cataract_Segment__c',
                type: 'text',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: staticLabel12,
                fieldName: 'Medicare_Procedure__c',
                type: 'Number',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: staticLabel13,
                fieldName: 'JNJ_IOL_share__c',
                type: 'percent',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: staticLabel14,
                fieldName: 'Available_Doctor_P1__c',
                type: 'text',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: staticLabel15,
                fieldName: 'Doc1_Available_Datetime__c',
                type: 'text',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: staticLabel16,
                fieldName: 'Available_Doctor_P2__c',
                type: 'text',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: staticLabel17,
                fieldName: 'Doc_2_Available_Datetime__c',
                type: 'text',
                sortable: true,
                "initialWidth": 155
            },
            {
                label: staticLabel18,
                fieldName: 'Account_Addess__c',
                type: 'text',
                sortable: true,
                "initialWidth": 155
            }
        ]);
        helper.fetchNegativesAccounts(cmp);
    },
});