({
    loadDataToCalendar: function (component, data) 
    {
        //Find Current date for default date
        let d = new Date();
        let month = d.getMonth() + 1;
        let day = d.getDate();
        let currentDate = d.getFullYear() + '/' +
            (month < 10 ? '0' : '') + month + '/' +
            (day < 10 ? '0' : '') + day;
        
        let self = this;
        $('#calendar')
        .fullCalendar({
            header: {
                left: 'prev,next today',
                center: 'title',
                right: 'month,basicWeek,basicDay'
            },
            selectable: true,
            defaultDate: currentDate,
            editable: true,
            eventLimit: true,
            events: data,
            dragScroll: true,
            droppable: true,
            weekNumbers: true,
            eventDrop: function (event, delta, revertFunc) 
            {
                if (!confirm("Are you sure about this change?")) 
                {
                    revertFunc();
                } 
                else 
                {
                    let eventid = event.id;
                    let eventdate = event.start.format();
                    self.editEvent(component, eventid, eventdate);
                }
            },
            eventClick: function (event, jsEvent, view) 
            {
                let editRecordEvent = $A.get("e.force:editRecord");
                editRecordEvent.setParams({
                    "recordId": event.id
                });
                editRecordEvent.fire();
            },
            dayClick: function (date, jsEvent, view) 
            {
                let datelist = date.format().toString().split('-');
                let datetime = new Date(datelist[0], parseInt(datelist[1], 10) - 1, parseInt(datelist[2], 2) + 1, 0, 0, 0, 0);
                let createRecordEvent = $A.get("e.force:createRecord");
                createRecordEvent.setParams({
                    "entityApiName": "Event",
                    "defaultFieldValues": {
                        'StartDateTime': datetime
                    }
                });
                createRecordEvent.fire();
            },
            eventMouseover: function (event, jsEvent, view) 
            {
            }
        });
    },
    formatFullCalendarData: function (component, events) 
    {
        let josnDataArray = [];
        for (let i = 0; i < events.length; i++) 
        {
            let startdate = $A.localizationService.formatDate(events[i].StartDateTime);
            let enddate = $A.localizationService.formatDate(events[i].EndDateTime);
            let startdate1 = $A.localizationService.formatTime(events[i].StartDateTime);
            let enddate1 = $A.localizationService.formatTime(events[i].EndDateTime);
            
            if (events[i].WhatId && events[i].WhoId) 
            {
                josnDataArray.push({
                    'title': events[i].Subject + "\n" + events[i].What.Name + "\n" + events[i].Who.Name + "\n" + startdate1 + "-" + enddate1,
                    'start': startdate,
                    'end': enddate,
                    'id': events[i].Id
                });
            } 
            else if (!events[i].WhatId && events[i].WhoId) 
            {
                josnDataArray.push({
                    'title': events[i].Subject + "\n" + "-" + "\n" + events[i].Who.Name + "\n" + startdate1 + "-" + enddate1,
                    'start': startdate,
                    'end': enddate,
                    'id': events[i].Id
                });
            } else if (events[i].WhatId && !events[i].WhoId) 
            {
                josnDataArray.push({
                    'title': events[i].Subject + "\n" + events[i].What.Name + "\n" + "-" + "\n" + startdate1 + "-" + enddate1,
                    'start': startdate,
                    'end': enddate,
                    'id': events[i].Id
                });
            } 
                else 
                {
                    josnDataArray.push({
                        'title': events[i].Subject + "\n" + "-" + "\n" + "-" + "\n" + startdate1 + "-" + enddate1,
                        'start': startdate,
                        'end': enddate,
                        'id': events[i].Id
                    });
                }
        }
        return josnDataArray;
    },
    
    fetchCalenderEvents: function (component) 
    {
        let action = component.get("c.getAllEvents");
        
        action.setCallback(this, function (response) {
            let state = response.getState();
            if (state === "SUCCESS")
            {
                let josnArr = this.formatFullCalendarData(component, response.getReturnValue());
                this.loadDataToCalendar(component, josnArr);
                component.set("v.Objectlist", josnArr);
            } 
            else if (state === "ERROR")
            {
                let errors = response.getError();
                if (errors) 
                {
                    if (errors[0] && errors[0].message) 
                    {
                        $A.log("Errors", errors);
                    }
                }
            }
        });
        $A.enqueueAction(action);
    },
});