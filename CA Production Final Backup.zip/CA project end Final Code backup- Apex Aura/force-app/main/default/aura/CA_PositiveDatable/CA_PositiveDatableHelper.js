({
    sortData: function (cmp, fieldName, sortDirection)
    {
        let data = cmp.get("v.callPlannerList");
        let reverse = sortDirection !== 'asc';
        data.sort(this.sortBy(fieldName, reverse));
        cmp.set("v.callPlannerList", data);
    },
    
     sortBy: function (field, reverse, primer)
    {
        let key = primer ? function (x) {
            return primer(x[field]);
        } : function (x) {
            return x[field];
        };
        reverse = !reverse ? 1 : -1;
        return function (a, b) {
            return a = key(a), b = key(b), reverse * ((a > b) - (b > a));
        };
    },
    
    fetchPosAccounts: function (component)
    {
        let action = component.get("c.getCallPlannerRec");
        action.setParams({});
        action.setCallback(this, function (response) {
            let state = response.getState();
            if (state === "SUCCESS")
            {
                let records = response.getReturnValue();
                component.set("v.callPlannerList", response.getReturnValue());
                records.forEach(function (record) {
                    record['linkName'] = '/lightning/r/Account/' + record['AccountId__c'] + '/view';
                });
                for (let i = 0; i < records.length; i++)
                {
                    if (records[i].Call_Target_Meet__c == 1)
                    {
                        records[i].buttonColor = 'destructive';
                    }
                    else
                    {
                        records[i].buttonColor = 'destructive-text';
                    }
                }
                component.set("v.callPlannerList", records);
            } 
            else if (state === "ERROR")
            {
                let errors = response.getError();
                if (errors)
                {
                    $A.log("Errors", errors[0].message);
                }
            }
        });
        $A.enqueueAction(action);
    },
})